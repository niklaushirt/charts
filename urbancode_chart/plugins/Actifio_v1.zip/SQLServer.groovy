import groovyx.net.http.RESTClient
import groovy.json.JsonSlurper
import groovy.transform.Field

def workDir = new File('.').canonicalFile
final def props = new Properties()
final def inputPropsFile = new File(args[0])

try {
	inputPropsStream = new FileInputStream(inputPropsFile)
	props.load(inputPropsStream)
}
catch (IOException e) {
	throw new RuntimeException(e)
}

def applianceName = props['applianceName']
def userName = props['userName']
def passWord = props['passWord']
def apiKey = props['apiKey']
def sourceApplication = props['sourceApplication']
def backupImage = props['backupImage']
def targetHost = props['targetHost']
def targetInstance = props['targetInstance']
def databaseName = props['databaseName']
def bringOnline = props['bringOnline']
def dbUser = props['dbUser']
def dbPassword = props['dbPassword']
@Field String sessionId;
@Field String imageId;

def login(String applianceName, String userName, String passWord, String apiKey) {
	def client = new RESTClient("https://${applianceName}")
	client.ignoreSSLIssues()
	def resp = client.get(path : "/actifio/api/login",
		 query: [
			"name" : userName,
			"password" : passWord,
			"vendorkey" : apiKey
		 ],
		 headers: [
			 "Accept" : "application/json"
		 ]
	)
	
	assert resp.status == 200  // HTTP response code; 404 means not found, etc.
	
	def jsonMap = resp.getData()
	sessionId = jsonMap.get("sessionid")
	
	println sessionId
}

def getImage(String applianceName, String sessionid, String sourceApplication, String backupImage) {
	def client = new RESTClient("https://${applianceName}")
	client.ignoreSSLIssues()
	def resp = client.get( path : "/actifio/api/info/lsbackup",
		 query: [
			"filtervalue" : "appname=${sourceApplication}&jobclass=snapshot&apptype=SqlServerWriter&componenttype=0",
			"sessionid" : sessionId
		 ],
		 headers: [
			 "Accept" : "application/json"
		 ]
	)
	
	assert resp.status == 200  // HTTP response code; 404 means not found, etc.
	
	def jsonMap = resp.getData()
	def images = jsonMap.get("result").getAt("backupname")
	def sorted = images.reverse()
	
	if(backupImage == "Recent") {
		imageId = sorted[0]
	}
	else {
		imageId = sorted[sorted.size() - 1]
	}
	
	println imageId
}

def mountImage(String applianceName, String sessionId, String imageId, String targetHost, 
	String targetInstance, String databaseName, String bringOnline, String dbUser, String dbPassword) {
	def recover;
	
	if(bringOnline == "Yes") {
		recover = "true"
	}
	else {
		recover = "false"
	}
		
	def client = new RESTClient("https://${applianceName}")
	client.ignoreSSLIssues()
	def resp = client.post(path : "/actifio/api/task/mountimage",
		 query: [
			"image" : imageId,
			"host" : targetHost,
			"appaware" : "true",
			"restoreoption" : "provisioningoptions=<provisioning-options><sqlinstance>${targetInstance}</sqlinstance><dbname>${databaseName}</dbname><recover>${recover}</recover><username>${dbUser}</username><password>${dbPassword}</password></provisioning-options>",
			"sessionid" : sessionId
		 ],
		 headers: [
			 "Accept" : "application/json"
		 ]
	)

	assert resp.status == 200  // HTTP response code; 404 means not found, etc.
	
	def jsonMap = resp.getData()

	if(jsonMap.containsKey("status")) {
		println jsonMap.get("result");
		return System.exit(0)
	}
	else {
		println jsonMap.get("errormessage")
		return System.exit(1)
	}
}

login(applianceName, userName, passWord, apiKey)
getImage(applianceName, sessionId, sourceApplication, backupImage)
mountImage(applianceName, sessionId, imageId, targetHost, targetInstance, databaseName, bringOnline, dbUser, dbPassword)
